const databind = new Databind(document.querySelector('#example'), {
    aaa: '1',
    bbb: '2',
    ccc: '3',
    ddd: '4',
});

