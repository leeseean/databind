class Databind {
    constructor(el, data) {
        if (!el) return;
        this.el = el;
        this.data = data || {};
        this.init();
        this.register();
        return this.proxy;
    }
    init() {
        this.el.querySelectorAll('[data-bind]').forEach((ele, index) => {
            const key = ele.getAttribute('data-bind');
            this.refreshDom(ele, this.data[key]);
        });
    }
    register() {
        const that = this;
        this.proxy = new Proxy(this.data, {
            get(target, key, receiver) {
                return Reflect.get(target, key, receiver);
            },
            set(target, key, value, receiver) {
                that.el.querySelectorAll('[data-bind]').forEach((ele, index) => {
                    if (ele.getAttribute('data-bind') === key && target[key] !== value) {
                        that.refreshDom(ele, value);
                    }
                });
                return Reflect.set(target, key, value, receiver);
            },
            deleteProperty(target, key) {
                return Reflect.deleteProperty(target, key);
            }
        });
        this.inputBind();
    }
    inputBind() { // 输入框值变化更新对象值
        this.el.querySelectorAll('[data-bind]').forEach((ele, index) => {
            const key = ele.getAttribute('data-bind');
            if (ele.nodeName === 'INPUT' || ele.nodeName === 'TEXTAREA' || ele.nodeName === 'SELECT') {
                ele.addEventListener('input', (e) => {
                    this.proxy[key] = e.target.value;
                });
            }
        });
    }
    refreshDom(ele, value) {
        if (ele.nodeName === 'INPUT' || ele.nodeName === 'TEXTAREA' || ele.nodeName === 'SELECT') {
            ele.value = value;
        } else {
            ele.innerText = value;
        }
    }
}

//是不是一个pure object,意思就是object里面没有再嵌套object了
function isPureObject(object) {
    if (typeof object !== 'object') {
        return false;
    } else {
        for (let prop in object) {
            if (typeof object[prop] == 'object') {
                return false;
            }
        }
    }
    return true;
}