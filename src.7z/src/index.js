const {
    CreateProxy
} = require('./CreateProxy');
const {
    setValue
} = require('./deepProxy');

module.exports = {
    CreateProxy,
    setValue
};