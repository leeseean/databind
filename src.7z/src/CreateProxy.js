const {
    deepProxy, setValue
} = require('./deepProxy');

class CreateProxy {
    static arr = [];// 这个数组存放'a.b.c'中的a,b,c
    constructor(el, data) {
        if (!el) throw '找不到挂载的dom';
        this.el = el;
        this.data = data || {};
        this.init();
        this.register();
        return this.proxy;
    }
    init() {
        this.el.querySelectorAll('[data-bind]').forEach((ele, index) => {
            const key = ele.getAttribute('data-bind');
            const arrKey = key.split('.');// 'a.b.c' => ['a', 'b', 'c']
            this.refreshDom(ele, arrKey.reduce((val, item) => val[item], this.data));
        });
    }
    register() {
        this.proxy = deepProxy(this.data, (directAttrValue, value) => {
            this.el.querySelectorAll('[data-bind]').forEach(ele => {
                const key = ele.getAttribute('data-bind');
                if (directAttrValue === key) {
                    this.refreshDom(ele, value);
                }
            });
        });
        this.inputBind();
    }
    inputBind() { // 输入框值变化更新对象值
        this.el.querySelectorAll('[data-bind]').forEach((ele, index) => {
            const key = ele.getAttribute('data-bind');
            if (ele.nodeName === 'INPUT' || ele.nodeName === 'SELECT' || ele.nodeName === 'TEXTAREA') {
                ele.addEventListener('input', (e) => {
                    setValue(() => {
                        const func = new Function('proxyObj', 'evt', `proxyObj.${key} = evt.target.value`);
                        func(this.proxy, e);
                    });
                });
            }
        });
    }
    refreshDom(ele, value) {
        if (ele.nodeName === 'INPUT' || ele.nodeName === 'SELECT' || ele.nodeName === 'TEXTAREA') {
            ele.value = value;
        } else {
            ele.textContent = value;
        }
    }
}

module.exports = { CreateProxy };